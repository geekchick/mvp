class Basketball < ActiveRecord::Base
			belongs_to :user
end

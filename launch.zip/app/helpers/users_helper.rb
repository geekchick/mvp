module UsersHelper
	def facebook_image(user)
		#fb_url = "https://graph.facebook.com/#{user.uid}/picture"
		
	end	
end


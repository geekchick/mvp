require 'spec_helper'

describe BaseballProfile do
  pending "add some examples to (or delete) #{__FILE__}"
end

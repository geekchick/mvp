Formtastic::Helpers::FormHelper.builder = FormtasticBootstrap::FormBuilder

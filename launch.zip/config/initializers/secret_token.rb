# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
MyMvp::Application.config.secret_token = 'b624914d7dad6e498a11274563c27bdd405ac28c1e03605e3bb52bc7d1948a4a253d2eb50d84064a3d10a5493796b40d612fe7198740ed5e3bb1505d9260a927'
